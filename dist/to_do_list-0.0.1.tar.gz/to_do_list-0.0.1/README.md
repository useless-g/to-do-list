Description
===========
RESTapi for todo-list

Stack: FastAPI, sqlalchemy, databases, alembic, pydantic, pytest
